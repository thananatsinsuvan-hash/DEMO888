# ระบบบันทึกค่าใช้จ่ายผู้สูงอายุ — เวอร์ชัน Cloudflare D1 + Login

โครงสร้างโปรเจกต์:

```
.
├── schema.sql            ตารางฐานข้อมูล D1 (รวมตาราง users สำหรับ login)
├── wrangler.toml          การตั้งค่า Worker + binding ไป D1/Assets
├── package.json
├── scripts/
│   └── create-user.js       สคริปต์สร้างผู้ใช้ใหม่ (คำนวณ hash รหัสผ่านให้)
├── src/
│   └── index.js              Worker API — login/session + ข้อมูลตามสิทธิ์สาขา
└── public/
    └── index.html             หน้าเว็บระบบ มีหน้า login ในตัว
```

## ระบบสิทธิ์การเข้าถึง

มี 2 บทบาท:
- **admin** — เห็น/แก้ไขได้ทุกองค์กร ทุกสาขา ทุกเคส และจัดการองค์กร/สาขาได้ (แท็บ "ตั้งค่าเอกสาร")
- **staff** — ล็อกอินแล้วเห็น**เฉพาะสาขาที่ผูกไว้กับบัญชีตัวเอง** เท่านั้น เพิ่ม/แก้ไข/ลบเคสและค่าใช้จ่ายได้เฉพาะในสาขาตัวเอง มองไม่เห็นและแก้ไขสาขาอื่นไม่ได้เลย (ฝั่งเซิร์ฟเวอร์บังคับสิทธิ์นี้ ไม่ใช่แค่ซ่อนที่หน้าเว็บ) และไม่เห็นแท็บ "ตั้งค่าเอกสาร" (จัดการองค์กร/สาขา)

## วิธีติดตั้งและรัน

### 1) เตรียมเครื่องมือ
```bash
npm install -g wrangler
wrangler login
npm install
```

### 2) สร้างฐานข้อมูล D1
```bash
wrangler d1 create care-billing-db
```
คัดลอกค่า `database_id` ที่ได้ไปแทนที่ `PASTE_YOUR_DATABASE_ID_HERE` ใน `wrangler.toml`

### 3) สร้างตารางในฐานข้อมูล
```bash
npm run db:init:remote
```

### 4) ตั้งค่า secret สำหรับเซ็น session (สำคัญ ห้ามข้าม)
```bash
wrangler secret put SESSION_SECRET
```
ระบบจะถามค่า — พิมพ์ข้อความสุ่มยาวๆ อะไรก็ได้ (เก็บเป็นความลับ ไม่ต้องจำ ใช้ครั้งเดียวตอนตั้งค่า)

### 5) Deploy ก่อน แล้วค่อยสร้างผู้ใช้
```bash
npm run deploy
```

### 6) สร้างองค์กร/สาขา (ผ่านหน้าเว็บ ด้วยบัญชี admin ชั่วคราว)
ก่อนจะสร้างผู้ใช้ staff ได้ ต้องรู้ `org_id` / `branch_id` ก่อน — สร้างบัญชี admin คนแรกด้วยคำสั่ง:
```bash
node scripts/create-user.js admin1 "รหัสผ่านที่ต้องการ" "ผู้ดูแลระบบ" admin
```
คำสั่งนี้จะพิมพ์ SQL ออกมา — คัดลอกไปรัน:
```bash
wrangler d1 execute care-billing-db --remote --command="INSERT INTO users (...) VALUES (...)"
```
(หรือบันทึกเป็นไฟล์ `seed-users.sql` แล้วรัน `wrangler d1 execute care-billing-db --remote --file=./seed-users.sql`)

จากนั้นเข้าเว็บ ล็อกอินด้วยบัญชี admin นี้ แล้วไปที่แท็บ **ตั้งค่าเอกสาร** เพื่อเพิ่มองค์กรและสาขาให้ครบตามต้องการ

### 7) หา org_id / branch_id เพื่อสร้างผู้ใช้ staff
```bash
wrangler d1 execute care-billing-db --remote --command="SELECT id,name FROM orgs"
wrangler d1 execute care-billing-db --remote --command="SELECT id,name,org_id FROM branches"
```

### 8) สร้างผู้ใช้ staff แต่ละคน (ทำซ้ำได้ถึง ~10 คนตามต้องการ)
```bash
node scripts/create-user.js somchai "รหัสผ่านคนที่1" "สมชาย มั่นคง" staff <org_id> <branch_id>
node scripts/create-user.js malee   "รหัสผ่านคนที่2" "มาลี ศรีสุข"  staff <org_id> <branch_id_อื่น>
```
คัดลอก SQL ที่ได้ไปรันกับ `wrangler d1 execute care-billing-db --remote --command="..."` ทีละคน

### 9) ทดสอบ
เปิด URL ของระบบ ล็อกอินด้วยบัญชี staff ที่สร้างไว้ → ควรเห็นเฉพาะเคส/ข้อมูลของสาขาที่ผูกไว้เท่านั้น และไม่เห็นแท็บ "ตั้งค่าเอกสาร"

## การจัดการผู้ใช้ภายหลัง

- **เปลี่ยนรหัสผ่าน**: รัน `create-user.js` ใหม่ด้วย username เดิม (ต้องลบ user เดิมก่อนด้วย `DELETE FROM users WHERE username='...'` เพราะ username ต้องไม่ซ้ำ) หรือรอให้ผมช่วยเพิ่มหน้า "จัดการผู้ใช้" ในเว็บให้ทีหลังได้
- **ลบผู้ใช้**: `wrangler d1 execute care-billing-db --remote --command="DELETE FROM users WHERE username='somchai'"`
- **ดูรายชื่อผู้ใช้ทั้งหมด**: `wrangler d1 execute care-billing-db --remote --command="SELECT username,display_name,role,branch_id FROM users"`

## หมายเหตุสำคัญ

- Session cookie อยู่ได้ 7 วันแล้วต้องล็อกอินใหม่ (ปรับได้ที่ `SESSION_MAX_AGE` ใน `src/index.js`)
- ระบบตอนนี้ไม่มีหน้าจัดการผู้ใช้ในเว็บ (ต้องสร้าง/ลบผ่าน CLI ตามขั้นตอนข้างบน) — เหมาะกับทีมเล็กๆ ~10 คนที่ไม่ได้เปลี่ยนบ่อย ถ้าต้องการหน้าเว็บสำหรับ admin จัดการผู้ใช้ได้เอง (เพิ่ม/ลบ/รีเซ็ตรหัสผ่าน) บอกได้ ทำเพิ่มให้ได้
- การบันทึกข้อมูลของ staff ทำงานแบบ "แทนที่ข้อมูลเฉพาะในสาขาตัวเอง" ทุกครั้งที่กดบันทึก — ปลอดภัยต่อข้อมูลสาขาอื่นเพราะฝั่งเซิร์ฟเวอร์ตรวจสอบ branch_id ทุกครั้งก่อนเขียนจริง ไม่ใช่แค่ซ่อนปุ่มที่หน้าเว็บ
